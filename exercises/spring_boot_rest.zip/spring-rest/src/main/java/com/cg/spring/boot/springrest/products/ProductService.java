package com.cg.spring.boot.springrest.products;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ProductService {

	List<Product> products = new ArrayList<>(Arrays.asList(
			new Product("s01", "Samsung", "Samsung Galaxy S9", 79000.0),
			new Product("ip01", "Iphone", "Iphone 6s", 45000.0)
			));
	
	public List<Product> getAllProducts() {
		return products;
	}

	public Product getProduct(String id) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getId().equals(id)) {
				return products.get(i);
			}
		}
		return null;
	}

	public void addProduct(Product p) {
		products.add(p);
		
	}

	public void updateProduct(String id, Product p) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getId().equals(id)) {
				products.set(i, p);
			}
		}
	}

	public void deleteProduct(String id) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getId().equals(id)) {
				products.remove(i);
			}
		}
		
	}

}
